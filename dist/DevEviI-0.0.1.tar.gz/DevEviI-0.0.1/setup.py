import setuptools
setuptools.setup(
    name= 'DevEviI',
    version= '0.0.1',
    author= 'XF',
    description= 'bY ~ t.me/DevEviI',
    packages=setuptools.find_packages(),
    classifiers=[
    "Programming Language :: Python :: 3",
    "Operating System :: OS Independent",
    "License :: OSI Approved :: MIT License"
    ]
)